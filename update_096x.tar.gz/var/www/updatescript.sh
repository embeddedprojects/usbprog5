#!/bin/bash
ldconfig


sync

