#!/bin/bash



sync

