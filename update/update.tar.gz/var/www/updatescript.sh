#!/bin/bash




sync
#reboot
